<?php
/////////
$auto = 'http://sextgem.com/autologin/1376671a7beb9d0149b7ad578b02cd72/c2Vua28uc2V4dGdlbS5jb20=';
/////////
$tenwap = explode('/',$auto);
$server = $tenwap[2];
$tenwap = base64_decode($tenwap[5]);
$ua = 'Opera/9.80 (J2ME/MIDP; Opera Mini/9.80 (S60; SymbOS; Opera Mobi/23.348; U; en) Presto/2.5.25 Version/10.54';
$cookies = 'cooki.txt';
$wap4 = 'http://csit.tk';
?>