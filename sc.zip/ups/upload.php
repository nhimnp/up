<?php
set_time_limit(1000);
include 'set.php';
include 'function.php';
$idfile = $_POST['idfile'];
$w4 = trim(file_get_contents($wap4.'/id?f='.$idfile));
 // Xử Lý Upload
    // Nếu người dùng click Upload
    if (isset($_POST['uploadclick']))
    {
        // Nếu người dùng có chọn file để upload
        if (isset($_FILES['file']))
        {
$error = $_FILES['file']['error'];
$size = $_FILES['file']['size'];
$name = $_FILES['file']['name'];
$type = $_FILES['file']['type'];
            // Nếu file upload không bị lỗi,
            // Tức là thuộc tính error > 0
if ($w4 != 1)
            {
header('Location: '.$wap4.'/up?type=not');
                echo 'Link sai';
            }
           else if ($error > 0)
            {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=errorfile');  
                echo 'File Upload Bị Lỗi';
            }
            elseif ($size > 15728639)
            {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=maxsize');  
                echo 'File quA dung luong';
            }
            else {
                // Upload file
                move_uploaded_file($_FILES['file']['tmp_name'], './folder/'.$name);
$fp = @fopen('folder/'.$name, "r");
  
// Kiểm tra file mở thành công không
if (!$fp) {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=notopen');  
    echo 'Mở file không thành công';
}
else
{
    // Đọc file và trả về nội dung
    $data = fread($fp, filesize('folder/'.$name));
    $filename = trim(filename($name,$type));
////upload/////
if (trim(file_get_contents($wap4.'/id?file='.$idfile)) == 0) {
tao_tm('/up',$idfile);
}
tao_file('/up/'.$idfile.'/'.$filename,$data);
tao_w4($idfile,$filename,$type,$size);
fclose($fp);
unlink('folder/'.$name);
header('Location: '.$wap4.'/up?file='.$idfile.'&type=on');
    echo $file;
    echo 'Upload thanh cong';
///////upload//////
}
            }
        }
        elseif ($w4 == 1) {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=nofile');  
            echo 'Bạn chưa chọn file upload';
        }
    }
?>