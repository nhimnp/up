<?php
set_time_limit(1000);
include 'set.php';
include 'function.php';
$url = isset($_POST['url']) ? $_POST['url'] : NULL;
$idfile = $_POST['idfile'];
$w4 = trim(file_get_contents($wap4.'/id?f='.$idfile));
if ($url != NULL) {
$name = basename($url);
$types = pathinfo($url, PATHINFO_EXTENSION);
$typee = array('jpg','mp3','png','jpeg','mp4','3gp','exe','gif','zip','js','apk','jar','jad','avi','pdf');
$size = strlen(file_get_contents($url));
if ($w4 != 1)
            {
header('Location: '.$wap4.'/up?type=not');
                echo 'Link sai';
            }
elseif (!isURL($url)) {
echo 'Url không hợp lệ';
header('Location: '.$wap4.'/up?file='.$idfile.'&type=notopen');
}
elseif ($size > 15728639)
{
header('Location: '.$wap4.'/up?file='.$idfile.'&type=maxsize');  
echo 'File quA dung luong';
}
else if(strlen($name) < '3'){
header('Location: '.$wap4.'/up?file='.$idfile.'&type=notopen');
Echo 'ngan';
}
elseif(!in_array($types,$typee)) {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=notopen');
Echo 'File không hợp lệ';
}
else if(import($url,'folder/'.$name)) {
$type = mime_content_type('folder/'.$name);
$size = filesize('folder/'.$name);
$fp = @fopen('folder/'.$name, "r");
// Kiểm tra file mở thành công không
if (!$fp) {
header('Location: '.$wap4.'/up?file='.$idfile.'&type=notopen');  
echo 'Mở file không thành công';
}
else
{
// Đọc file và trả về nội dung
$data = fread($fp, filesize('folder/'.$name));
$filename = trim(filename($name,$type));
////upload/////
if (trim(file_get_contents($wap4.'/id?file='.$idfile)) == 0) {
tao_tm('/up',$idfile);
}
tao_file('/up/'.$idfile.'/'.$filename,$data);
tao_w4($idfile,$filename,$type,$size);
fclose($fp);
unlink('folder/'.$name);
header('Location: '.$wap4.'/up?file='.$idfile.'&type=on');  
echo $idfile;
echo 'Upload thanh cong';
}
}
} elseif ($w4 == 1) {
echo 'Chưa nhập url';
header('Location: '.$wap4.'/up?file='.$idfile.'&type=noturl');
}