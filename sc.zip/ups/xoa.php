<?php
set_time_limit(1000);
include 'set.php';
include 'function.php';
$id = $_GET['id'];
$file = $_GET['file'];
$url = $_GET['url'];
$check = trim(file_get_contents($wap4.'/id?file='.$file.'&id='.$id));
if ($url == 'on') {
$on = header('Location: '.$wap4.'/up?file='.$file.'&type=xoa&url=on');
} else {
$on = header('Location: '.$wap4.'/up?file='.$file.'&type=xoa');
}
if ($check != '') {
if ($check == 1) {
echo xoa_file($file);
} else {
echo xoa_file($file.'/'.trim(file_get_contents($wap4.'/id?tenfile='.$file.'&id='.$id)));
}
echo file_get_contents($wap4.'/id?f='.$file.'&id='.$id.'&xoa=on');
echo $on;
} 
?>