<?php
$up = $_POST['up'];
if($up=='1'){
include 'upload.php';
} elseif($up=='2') {
include 'url.php';
} else {
echo 'Vào đây làm gì @@';
}
?>